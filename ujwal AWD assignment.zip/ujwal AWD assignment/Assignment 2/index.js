const data = require('./local');
const http = require('http');
const urlModule = require('url');
const fs = require('fs');
const mathUtility = require('./mathUtility');
const express = require('express');
const app = express();

//******QUE 1 to 7 ******/

// http.createServer((req,res)=>{
    
    // Assignment 2 QUE 13
    // console.log("Hello World");
    
    
    // Assignment 2 QUE 14
    // const url = req.url;
    // if(url){
    //     res.writeHead(200,"Successs");
    //     res.end("Welcome to the NodeJS App");
    // }


    // Assignment 2 QUE 15
    // const url = req.url;
    // if(url ==  '/home'){
    //     res.end('Welcome to home page')
    // }

    // if(url == '/student'){
    //     res.end('Welcome to student page')
    // }

    // if(url == '/faculty'){
    //     res.end('Welcome to faculty page')
    // }




    // Assignment 2 QUE 16
    // const url = req.url;
    // res.writeHead(200,{'Content-Type':'text/html'});
    // if(url == '/'){
    //     fs.readFile('index.html','utf8',(err,data)=>{
    //         if(err){
    //             res.end(err);
    //             console.log('in err');
    //         }else{
    //             console.log('ok success');
    //             res.end(data);
    //         }

    //     });
    // }else{
    //     res.writeHead(404,{'Content-Type':'text/plain'});
    //     res.end("Please Go Back");
    // }


    // Assignment 2 QUE 17
    // const query = urlModule.parse(req.url);
    // res.writeHead(200,{'Content-Type':'text/html'});
    // if(query.path == '/'){
    //     fs.readFile('./index.html','utf8',(err,data)=>{
    //         if(err){
    //             res.writeHead(404,{'Content-Type':'text/plain'});
    //             res.end(err);
    //         }else{
    //             res.end(data);
    //         }
    //     })
    // }

    // if(query.path == '/about'){
    //     fs.readFile('./about.html','utf8',(err,data)=>{
    //         if(err){
    //             res.writeHead(404,{'Content-Type':'text/plain'})
    //             res.end(err);
    //         }else{
    //             res.end(data);
    //         }
    //     });
    // }

    // if(query.path == '/contact'){
    //     fs.readFile('contactus.html','utf8',(err,data)=>{
    //         if(err){
    //             res.writeHead(404,{'Content-Type':'text/plain'});
    //             res.end(err);
    //         }else{
    //             res.end(data);
    //         }
    //     });
    // }

    
    //Assignment 2 Que 18
    // res.end(data.name);
    
    
    //Assignment 2 Que 19
    // let a  = 10;
    // let b = 5;
    // const url = req.url;
    // if(url == '/'){
    //     res.write(`The addition of ${a} and ${b} is ${mathUtility.add(a,b)}`+"\n");
    //     res.write(`The subtraction of ${a} and ${b} is ${mathUtility.sub(a,b)}`+"\n");
    //     res.write(`The multiplication of ${a} and ${b} is ${mathUtility.mul(a,b)}`+"\n");
    //     res.write(`The division of ${a} and ${b} is ${mathUtility.div(a,b)}`+"\n");
    //     res.end();
    // }


    //Assignment 2 Que 20
    // const url = req.url;
    //     //home url for running server
    // if(url == '/'){
    //     res.end('Chage URL');
    // }
    //     //read and add data to new file
    // if(url == '/add'){
    //     fs.readFile('./data.json','utf8',(err,data)=>{
    //         fs.writeFileSync('./newdata.json',data,(err)=>console.log(err));
    //         res.end("data added");
    //     });
    // }
    //     //update data in newly created file
    // if(url == '/update'){
    //     fs.readFile('./newdata.json','utf8',(err,data)=>{
    //         let obj = JSON.parse(data);
    //         obj.age = 60;
    //         let backToJson = JSON.stringify(obj);
    //         fs.writeFile('./newdata.json',backToJson,(err)=>{
    //             if(err){
    //                 res.end(err);
    //             }else{
    //                 res.end('Age in Json Obj is Updated');
    //             }
    //         })
    //     });
    // }

    //     // delete data in new file and override old json file
    //     if(url == '/delete'){
    //         fs.readFile('./newdata.json','utf8',(err,data)  => {
    //             let obj = JSON.parse(data);
    //             delete obj.lastName;
    //             let backToJson = JSON.stringify(obj);

    //             fs.writeFile('./data.json',backToJson,'utf8',(err)=>{
    //                 if(err){
    //                     res.end(err);
    //                 }else{
    //                     res.end("last name is delete and file is overriden");
    //                 }
    //             })
    //         })
    //     }

 
// }).listen(8080,()=>console.log('the server is running on port http://localhost:8080'));

// ************** Node js Que end's here, and express related que starts from here.*************

// Assignment 2 Que 21
// app.use(express.static(__dirname));
// app.get('/',(req,res)=>{
//     res.sendFile('index.html');
//     res.end();
// });
// app.listen(8080,()=>console.log('Your app is running on port http://localhost:8080'));



// Assignment 2 que 22
const tasks = [
    { id: 1, title: 'Task 1', completed: false },
    { id: 2, title: 'Task 2', completed: true },
  ];

    //api for getting data
app.get("/",(req,res)=>{
    res.json(tasks);
});

    // api for adding data;
app.post('/addData',(req,res)=>{
    const newTask = req.body;
    tasks.push(newTask);
    res.status(200).json({"message":"Record Added"});
});

    // api for deleting the record
app.delete('/delete/:id',(req,res)=>{
    const id = req.params.id;
    const existingRecord  = tasks.findIndex(x => x.id == id);
    if(existingRecord){
        tasks.splice(existingRecord,1);
        res.status(200).json({"message":"Record Deleted"});
    }else{
        res.status(404).json({"error":"Record Not Found"});
    }
});

    //api for geting specific single record
app.get('/edit/:id',(req,res)=>{
    const id = req.params.id;
    const record = tasks.find(x => x.id == id);
    if(!record){
        res.writeHead(404,{error:"Record Not Found"});
    }else{
        res.json(record);
    }
    
});

    // api for updating data
app.put('/update',(req,res)=>{
    const fromData = req.body;
    const recordId = fromData.id;
    const recordIndex  = tasks.findIndex(x => x.id == recordId);
    tasks[recordIndex] = fromData;

    res.status(200).json({"message":"Record Updated"});
});