// import { staticData } from './model';


// Assignment 1 QUE 6
const app = angular.module("myapp", []);
// app.controller("myctrl",function($scope){

//     $scope.list = [
//         {productName:"OnePlus",price:2000},
//         {productName:"Lenove",price:5000}
//     ]
// });


// Assignment 1 QUE 7
// const anglr = angular.module("myapp",[]);
// anglr.controller("myctrl",function($scope){

//     $scope.taskData = [
//         {subID:"sub1",subName:"AWD"},
//         {subID:"sub2",subName:"DA"},
//         {subID:"sub3",subName:"GC"},
//     ]

// });

// Assignment 1 QUE 9
// app.controller("myctrl",function($scope){
//     $scope.message = staticData;
// });


// Assignment 1 QUE 10
app.controller('myctrl', function ($scope) {
    $scope.studentInfo = studentInfo;
    $scope.s1 = "";
    $scope.s2 = "";
    $scope.s3 = "";
    $scope.total = "";
    $scope.percentage = "";
    $scope.detailInfo = function (specificStudent) {
        $scope.s1 = specificStudent.s1
        $scope.s2 = specificStudent.s2
        $scope.s3 = specificStudent.s3
        $scope.total = $scope.s1 + $scope.s2 + $scope.s3;
        $scope.s1Grade = calculateGrade($scope.s1);
        $scope.s2Grade = calculateGrade($scope.s2);
        $scope.s3Grade = calculateGrade($scope.s3);
        $scope.percentage = calcPercentage($scope.total);
    }

    //calculate grade
    function calculateGrade(marks) {
        if (marks > 80) {
            return "AA";
        } else if (marks > 75 && marks <= 80) {
            return "AB";
        } else if (marks > 70 && marks <= 75) {
            return "BB";
        } else if (marks > 65 && marks <= 70) {
            return "BC";
        } else if (marks > 60 && marks <= 65) {
            return "CC";
        } else if (marks > 55 && marks <= 60) {
            return "CD";
        } else if (marks => 50 && marks <= 55) {
            return "DD";
        } else {
            return "FF";
        }
    }

    //calcPercentage
    function calcPercentage(stuTotal) {
        const per = (stuTotal * 100) / 300;
        return per.toFixed(2);
    }

});