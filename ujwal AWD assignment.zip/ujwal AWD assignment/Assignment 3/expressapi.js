const express = require('express');
const connectDB = require('./db');
const mongoose = require('mongoose');
const app = express();
app.use(express.static(__dirname));
app.use(express.json());
connectDB();

//defining schema
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;
const productSchema = new Schema({
    // id: ObjectId,
    pname: String,
    pprice: Number,
    pcategory: String
});


const Product = mongoose.model('ass3', productSchema);

app.get('/', (req, res) => {
    res.sendFile('index.html');
});


//Get data
app.get('/data', async (req, res) => {
    try {
        const data = await Product.find();
        res.send(data);
    } catch (error) {
        console.log(error);
    }
});

//Adding new data
app.post('/addData', async (req, res) => {
    try {
        const formData = new Product(req.body);
        const sentData = await formData.save();
        res.status(201).json({ "message": "Record Added" });
        res.send();
    } catch (error) {
        console.log(error);
    }
});


//Deleting data
app.delete('/delete/:id', async (req, res) => {
    const id = req.params.id;
    // res.json(id);
    const productDeleted = await Product.findOneAndRemove({ _id: id });

    if (!productDeleted) {
        res.json("Product Not Deleted");
    }
    res.status(200).json({ "message": "Record Deleted" });

})


//Editing data 
app.put('/edit/:id',async (req,res)=>{
    const id  = req.params.id;
    const data = await Product.findById(id);
    res.json(data);
});

//Updating Data
app.put('/update',async (req,res)=>{
    const id = req.body._id;
    const updatedData = {
        pname: req.body.pname,
        pprice: req.body.pprice,
        pcategory: req.body.pcategory,
      };
      
    const result = await Product.findByIdAndUpdate(id,updatedData,{new:true}).then(()=>{
        res.status(200).json("Record Updated")
    }).catch((err)=>console.log(err));
    
});

app.listen(8080, () => console.log('the server is running on http://localhost:8080'));