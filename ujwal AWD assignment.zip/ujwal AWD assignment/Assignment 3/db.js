const mongoose = require('mongoose');

const dbURL = "mongodb://127.0.0.1:27017/MyDatabase";

//connecting to db using mongoose
const connectDB = async () =>{
    try {
        const conn = await mongoose.connect(dbURL)
        if(conn){
            // console.log(conn.connection.host);
            console.log("str"+conn.connection.host);
        }
    } catch (error) {
        console.log(error);
    }
};

module.exports = connectDB;