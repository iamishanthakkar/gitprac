const app = angular.module('myapp', []);

app.controller('myctrl', function ($scope, $http) {
    $scope.prodData = [];

    $scope.listData = () => {
        $http.get('http://localhost:8080/data').then((response) => {
            console.log(response.data);
            $scope.prodData = response.data
        });
    }

    $scope.addData = () => {
        $http.post('http://localhost:8080/addData', $scope.formData).then(() => $scope.listData());
        let formId = document.getElementById('myForm');
        formId.reset();
    }


    $scope.delRecord = (id) => {
        $http.delete(`http://localhost:8080/delete/${id}`).then((res) => $scope.listData());

    }

    $scope.editData = (id) => {
        $http.put(`http://localhost:8080/edit/${id}`).then((res) => {
            $scope.formData = res.data;
            document.getElementById('updateDataBtn').style.display = "block";
            document.getElementById('addDataBtn').style.display = "none";
            document.getElementById('headText').innerText = "Update Record";
        });
    }

    $scope.updateData = () => {
        $http.put(`http://localhost:8080/update`, $scope.formData).then(() => { $scope.listData() });
        document.getElementById('updateDataBtn').style.display = "none";
        document.getElementById('addDataBtn').style.display = "block";
        document.getElementById('headText').innerText = "Add New Record";
        let formId = document.getElementById('myForm');
        formId.reset();
    }

    $scope.listData();
});