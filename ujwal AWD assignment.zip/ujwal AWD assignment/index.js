// Assingmnet 1 QUE 1
// const list = [{
//     "username": "ujwal",
//     "password": "qwerty"
// }]
// function logincheck() {
//     let uname = document.getElementById("uname").value;
//     let upass = document.getElementById("upass").value;

//     let checkUser = list.find(x=> x.username == uname && x.password == upass);

//     if (checkUser) {
//         alert("login success!!!")
//     } else {
//         alert("Invalid Username or Password");
//     }
// }


// Assingmnet 1 QUE 2
// const user = [
//     { "id": "1", "uname": "ujwal", "age": "21" },
//     { "id": "2", "uname": "manush", "age": "23" },
//     { "id": "3", "uname": "ishan", "age": "22" },
// ]
// let tbdy = document.getElementById("tbdy");

// let addBtn = document.getElementById("addBtn");
// addBtn.addEventListener("click", function () {
//     const id = document.getElementById("id").value;
//     const uname = document.getElementById("uname").value;
//     const age = document.getElementById("age").value;

//     const formData = {
//         "id": id,
//         "uname": uname,
//         "age": age
//     }

//     user.push(formData);
//     document.getElementById("myForm").reset();
//     tbdy.innerHTML = "";
//     showData();
// });

// function showData(){
//     user.map((item) => {
//         tbdy.innerHTML += `
//         <tr>
//         <td>${item.id}</td>
//         <td>${item.uname}</td>
//         <td>${item.age}</td>
//         <td><button type="button" id="updateBtn" id="updateBtn" onclick=updateData(this.value) value="${item.id}">Update</button></td>
//         <td><button type="button" id="delBtn" onclick=delData(this.value) value="${item.id}">Delete</button></td>
//       </tr>
//         `
//     })
// }
// showData();

// function updateData(id){ 
//     document.getElementById("addBtn").style.display ="none";
//     document.getElementById("updateBtn").style.display ="inline";
//     document.getElementById("id").style.display ="none";
//     let usr = user.find(x => x.id == id);
    
//     document.getElementById("id").value = usr.id;
//     document.getElementById("uname").value = usr.uname;
//     document.getElementById("age").value =  usr.age;

// }
// const updateBtn = document.getElementById("updateBtn");
// updateBtn.addEventListener('click',function(){
//     let updateid = document.getElementById("id").value ;
//     let updatename = document.getElementById("uname").value;
//     let updateage = document.getElementById("age").value;

//     const upUser = user.find(x => x.id == updateid);
//     upUser.uname = updatename;
//     upUser.age = updateage;
//     tbdy.innerHTML = "";
//     showData();
//     document.getElementById("id").style.display="inline";
//     document.getElementById("updateBtn").style.display="none";
//     document.getElementById("addBtn").style.display="inline";
//     document.getElementById("myForm").reset();
// });

// function delData(id){ 
//     let usr = user.findIndex(x => x.id == id);
//     user.splice(usr,1);
//     tbdy.innerHTML = "";
//     showData();
// }




//Assignment 1 OUE 3
 