var staticData = {
    message:"Hello World"
}


// Assignment 1 QUE 10
const studentInfo = [
    { sName: 'John Doe', sID: 'S001', course: 'Computer Science', age: 20, s1: 70, s2: 90, s3: 80 },
    { sName: 'Jane Smith', sID: 'S002', course: 'Mathematics', age: 22, s1: 60, s2: 75, s3: 65 },
    { sName: 'Alice Johnson', sID: 'S003', course: 'Physics', age: 21, s1: 80, s2: 65, s3: 70 },
    { sName: 'Bob Brown', sID: 'S004', course: 'Engineering', age: 19,  s1: 90, s2: 80, s3: 80 },
    { sName: 'Eva Wilson', sID: 'S005', course: 'Biology', age: 23, s1:80, s2: 80, s3: 90 }
];

modules.exports = {studentInfo,staticData};
